
from fastapi import FastAPI
from pydantic import BaseModel
import random

app=FastAPI(title="PlanetIQ MVP")

class Location(BaseModel):
    latitude: float
    longitude: float

def ecosystem_score(temp, rain, ndvi, fires):
    score=50
    score += ndvi*40
    score += min(rain/5,10)
    score -= max(temp-30,0)
    score -= fires*5
    return max(0,min(100,round(score)))

@app.get("/")
def root():
    return {"name":"PlanetIQ MVP","status":"running"}

@app.post("/analyze")
def analyze(loc:Location):
    # Placeholder values until real APIs are connected
    temp=round(random.uniform(22,36),1)
    rain=round(random.uniform(0,50),1)
    ndvi=round(random.uniform(0.3,0.95),2)
    fires=random.randint(0,3)

    score=ecosystem_score(temp,rain,ndvi,fires)

    if score>80:
        risk="Low"
    elif score>60:
        risk="Medium"
    else:
        risk="High"

    return {
        "location":{
            "latitude":loc.latitude,
            "longitude":loc.longitude
        },
        "weather":{
            "temperature":temp,
            "rainfall":rain
        },
        "vegetation_ndvi":ndvi,
        "nearby_fire_hotspots":fires,
        "ecosystem_health":score,
        "risk":risk
    }
