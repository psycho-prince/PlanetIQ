# PlanetIQ MVP

Run:

pip install -r requirements.txt
uvicorn backend.main:app --reload

Open:
http://127.0.0.1:8000/docs

POST /analyze

{
 "latitude":9.98,
 "longitude":76.28
}

This MVP uses simulated environmental values. Replace the placeholder logic with real weather, satellite and fire connectors later.
